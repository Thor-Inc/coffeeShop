package pl.sda.ristoretoCoffeeShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RistoretoCoffeeShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
